
#ifndef __STM32F10x_IT_H
#define __STM32F10x_IT_H


#include "stm32f10x.h"

void TIM2_IRQHandler(void);
void TIM3_IRQHandler(void);
void TIM4_IRQHandler(void);
void TIM5_IRQHandler(void);
void EXTI9_5_IRQHandler(void);
void EXTI1_IRQHandler(void);
#endif 
